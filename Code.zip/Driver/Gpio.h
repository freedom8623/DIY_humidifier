#ifndef __GPIO_H_
#define __GPIO_H_
#include "stc8h.h"
void Gpio_init(void);
#endif