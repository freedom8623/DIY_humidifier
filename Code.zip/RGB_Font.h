#ifndef __RGB_FONT_H
#define __RGB_FONT_H 	 

unsigned char code colorcode[][3]{

{111,000,00};

{};
{};
{};
{};
{};
};


#endif